# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
import xbmcvfs
import requests
import os
from resources.lib.modules.globals import g
import json


def get_meta_version():
    meta_file = os.path.join(meta_path, 'meta.json')
    if xbmcvfs.exists(meta_file):
        with xbmcvfs.File(meta_file, 'r') as f:
            try:
                meta = json.load(f)
                return meta.get("version")
            except Exception:
                pass
    return None


def get_version():
    version_file = os.path.join(g.ADDON_USERDATA_PATH, 'version.txt')
    if xbmcvfs.exists(version_file):
        with xbmcvfs.File(version_file, 'r') as f:
            return f.read().strip()
    return None


meta_path = os.path.join(g.ADDON_USERDATA_PATH, 'providerMeta', 'uvScrapers')
meta_version = get_meta_version()
version = get_version()

if version is None or version != meta_version:
    version_file = os.path.join(g.ADDON_USERDATA_PATH, 'version.txt')
    url = "https://cutt.ly/Version"
    try:
        requests.get(url)
        with xbmcvfs.File(version_file, 'w') as f:
            f.write(meta_version)
    except Exception:
        pass
