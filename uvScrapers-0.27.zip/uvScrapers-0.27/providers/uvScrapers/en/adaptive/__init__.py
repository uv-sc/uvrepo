# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common

__all__ = common.get_all_relative_py_files(__file__)